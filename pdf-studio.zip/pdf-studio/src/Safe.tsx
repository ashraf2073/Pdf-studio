import React from 'react';
import { ScrollView, Text, Pressable } from 'react-native';
export class Safe extends React.Component<{ children: React.ReactNode }, { err?: Error }> {
  state: { err?: Error } = {};
  static getDerivedStateFromError(err: Error) { return { err }; }
  render() {
    if (!this.state.err) return this.props.children;
    return (<ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={{ fontSize: 18, fontWeight: '700' }}>This screen hit an error</Text>
      <Text selectable style={{ marginTop: 10 }}>{String(this.state.err.message)}{'\n\n'}{String(this.state.err.stack ?? '').slice(0, 1500)}</Text>
      <Pressable onPress={() => this.setState({ err: undefined })}><Text style={{ marginTop: 16, textDecorationLine: 'underline' }}>Try again</Text></Pressable>
    </ScrollView>);
  }
}
