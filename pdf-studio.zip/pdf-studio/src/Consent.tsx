import React, { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
export type Item = { id: string; label: string; required?: boolean };
export type State = { ok: boolean; granted: Record<string, boolean> };
export function Consent({ scope, items, onChange }: { scope: string; items: Item[]; onChange: (s: State) => void }) {
  const key = `consent:${scope}`; const [g, setG] = useState<Record<string, boolean>>({});
  useEffect(() => { AsyncStorage.getItem(key).then(v => v && setG(JSON.parse(v))); }, []);
  useEffect(() => onChange({ ok: items.filter(i => i.required).every(i => g[i.id]), granted: g }), [g]);
  const tog = (id: string) => { const n = { ...g, [id]: !g[id] }; setG(n); AsyncStorage.setItem(key, JSON.stringify(n)); };
  return (<View style={{ padding: 12, borderWidth: 1, borderColor: '#ccc', borderRadius: 12, marginBottom: 12 }}>
    <Text style={{ fontWeight: '700' }}>Your consent</Text>
    {items.map(i => (<Pressable key={i.id} onPress={() => tog(i.id)} accessibilityRole="checkbox" accessibilityState={{ checked: !!g[i.id] }} style={{ flexDirection: 'row', gap: 10, paddingVertical: 8 }}>
      <View style={{ width: 22, height: 22, borderWidth: 2, borderRadius: 4, alignItems: 'center', justifyContent: 'center', backgroundColor: g[i.id] ? '#111' : '#fff' }}>{g[i.id] && <Text style={{ color: '#fff' }}>✓</Text>}</View>
      <Text style={{ flex: 1 }}>{i.label}{i.required ? ' *' : ''}</Text></Pressable>))}
    <Pressable onPress={() => { setG({}); AsyncStorage.removeItem(key); }}><Text style={{ textDecorationLine: 'underline' }}>Withdraw consent</Text></Pressable>
  </View>);
}
export const Btn = ({ t, onPress, off }: { t: string; onPress: () => void; off?: boolean }) => (
  <Pressable disabled={off} onPress={onPress} style={{ backgroundColor: off ? '#bbb' : '#111', padding: 12, borderRadius: 10, marginTop: 8 }}>
    <Text style={{ color: '#fff', textAlign: 'center', fontWeight: '600' }}>{t}</Text></Pressable>);
