import * as FS from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import { share } from './lib';
const K = 'dl:dir';
export async function download(uri: string, name: string, mime = 'application/pdf') {
  const SAF = FS.StorageAccessFramework;
  try {
    const b64 = await FS.readAsStringAsync(uri, { encoding: FS.EncodingType.Base64 });
    const put = async (dir: string) => {
      const f = await SAF.createFileAsync(dir, name.replace(/\.[^.]+$/, ''), mime);
      await FS.writeAsStringAsync(f, b64, { encoding: FS.EncodingType.Base64 });
    };
    const saved = await AsyncStorage.getItem(K);
    if (saved) { try { await put(saved); Alert.alert('Saved ✓', `${name} was saved to your chosen folder.`); return true; } catch {} }
    await new Promise<void>(r => Alert.alert('Choose a folder', 'Pick or create a folder such as Documents → PDF Studio. Android does not let apps use the Downloads root. You only do this once.', [{ text: 'Choose', onPress: () => r() }]));
    const p = await SAF.requestDirectoryPermissionsAsync();
    if (!p.granted) throw new Error('No folder chosen');
    await AsyncStorage.setItem(K, p.directoryUri); await put(p.directoryUri);
    Alert.alert('Saved ✓', `${name} was saved to the folder you chose.`); return true;
  } catch (e: any) {
    Alert.alert('Could not save', `${e.message}. Opening the share sheet instead.`); await share(uri, mime); return false;
  }
}
