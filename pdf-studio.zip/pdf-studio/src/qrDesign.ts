import qrcode from 'qrcode-generator';
(qrcode as any).stringToBytes = (qrcode as any).stringToBytesFuncs['UTF-8'];
export type Style = { body: string; eye: string; ball: string; grad: boolean; c1: string; c2: string; eyeColor: string; bg: string; logo?: string; logoScale: number };
export const SW = ['#111111', '#E5322D', '#F28C00', '#F2C200', '#1FA463', '#0FA3B1', '#1E6FE8', '#3B4BDB', '#7B4BD8', '#D6336C', '#8D5A3B', '#6B7280'];
export const BG = ['#FFFFFF', '#FFF4E5', '#E8F0FF', '#E6F7EE', '#FDECEC', '#F1EBFF', '#FFF9D6', '#14181F'];
const base: Style = { body: 'square', eye: 'square', ball: 'square', grad: false, c1: '#111111', c2: '#111111', eyeColor: '', bg: '#FFFFFF', logoScale: 0.2 };
export const PRESETS: [string, Partial<Style>][] = [
  ['Classic', {}], ['Rounded Blue', { body: 'rounded', eye: 'rounded', ball: 'circle', c1: '#1E6FE8' }],
  ['Party Dots', { body: 'dots', eye: 'circle', ball: 'circle', grad: true, c1: '#D6336C', c2: '#F28C00', bg: '#FFF4E5' }],
  ['Fresh Leaf', { body: 'rounded', eye: 'leaf', ball: 'leaf', grad: true, c1: '#1FA463', c2: '#0FA3B1', bg: '#E6F7EE' }],
  ['Royal', { body: 'diamond', eye: 'rounded', ball: 'leaf', grad: true, c1: '#7B4BD8', c2: '#3B4BDB', bg: '#F1EBFF' }],
  ['Ocean Bars', { body: 'bars', eye: 'rounded', ball: 'rounded', grad: true, c1: '#0FA3B1', c2: '#1E6FE8', bg: '#E8F0FF' }],
  ['Neon Night', { body: 'dots', eye: 'rounded', ball: 'circle', grad: true, c1: '#00E5FF', c2: '#FF4DA6', bg: '#14181F' }]];
export const mkStyle = (p: Partial<Style> = {}): Style => ({ ...base, ...p });
const f = (n: number) => +n.toFixed(2);
const rr = (x: number, y: number, w: number, h: number, r: number[]) => {
  const [a, b, c, d] = r.map(v => Math.max(v, 0.001));
  return `M${f(x + a)} ${f(y)}H${f(x + w - b)}A${f(b)} ${f(b)} 0 0 1 ${f(x + w)} ${f(y + b)}V${f(y + h - c)}A${f(c)} ${f(c)} 0 0 1 ${f(x + w - c)} ${f(y + h)}H${f(x + d)}A${f(d)} ${f(d)} 0 0 1 ${f(x)} ${f(y + h - d)}V${f(y + a)}A${f(a)} ${f(a)} 0 0 1 ${f(x + a)} ${f(y)}Z`;
};
const shape = (k: string, x: number, y: number, s: number) =>
  k === 'circle' ? rr(x, y, s, s, [s / 2, s / 2, s / 2, s / 2]) : k === 'rounded' ? rr(x, y, s, s, [s * .28, s * .28, s * .28, s * .28]) : k === 'leaf' ? rr(x, y, s, s, [s * .45, 0, s * .45, 0]) : rr(x, y, s, s, [0, 0, 0, 0]);
const mod = (k: string, c: number, r: number) => {
  if (k === 'dots') { const q = 0.42; return `M${f(c + .5 - q)} ${r + .5}a${q} ${q} 0 1 0 ${f(q * 2)} 0a${q} ${q} 0 1 0 ${f(-q * 2)} 0Z`; }
  if (k === 'diamond') return `M${c + .5} ${r}L${c + 1} ${r + .5}L${c + .5} ${r + 1}L${c} ${r + .5}Z`;
  if (k === 'rounded') return rr(c + .04, r + .04, .92, .92, [.3, .3, .3, .3]);
  if (k === 'bars') return rr(c + .12, r, .76, 1, [.38, .38, .38, .38]);
  return `M${c} ${r}h1v1h-1Z`;
};
export function build(text: string, s: Style) {
  const q = qrcode(0, s.logo ? 'H' : 'M'); q.addData(text, 'Byte'); q.make();
  const n = q.getModuleCount(), m = 4, u = n + 2 * m; let body = '', ring = '', ball = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
    if ((r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7)) continue;
    if (q.isDark(r, c)) body += mod(s.body, c + m, r + m);
  }
  [[0, 0], [n - 7, 0], [0, n - 7]].forEach(([a, b]) => { const x = a + m, y = b + m; ring += shape(s.eye, x, y, 7) + shape(s.eye, x + 1, y + 1, 5); ball += shape(s.ball, x + 2, y + 2, 3); });
  return { u, body, ring, ball };
}
export function svgStr(g: { u: number; body: string; ring: string; ball: string }, s: Style, size = 1024) {
  const u = g.u, ls = u * s.logoScale, lx = (u - ls) / 2, ec = s.eyeColor || s.c1;
  const defs = s.grad ? `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${s.c1}"/><stop offset="1" stop-color="${s.c2}"/></linearGradient></defs>` : '';
  const logo = s.logo ? `<rect x="${lx - 0.8}" y="${lx - 0.8}" width="${ls + 1.6}" height="${ls + 1.6}" rx="1.5" fill="${s.bg}"/><image href="${s.logo}" x="${lx}" y="${lx}" width="${ls}" height="${ls}"/>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${u} ${u}" width="${size}" height="${size}">${defs}<rect width="${u}" height="${u}" fill="${s.bg}"/><path d="${g.body}" fill="${s.grad ? 'url(#g)' : s.c1}"/><path d="${g.ring}" fill="${ec}" fill-rule="evenodd"/><path d="${g.ball}" fill="${ec}"/>${logo}</svg>`;
}
