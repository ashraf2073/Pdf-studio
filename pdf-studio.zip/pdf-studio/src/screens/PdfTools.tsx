import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { useLocalSearchParams } from 'expo-router';
import * as DP from 'expo-document-picker';
import { Directory, File, Paths } from 'expo-file-system';
import { PDFDocument, StandardFonts, LineCapStyle, rgb } from 'pdf-lib';
import { TOOLS } from '../tools';
import { CREDIT, save, share } from '../lib';
import { download } from '../download';
import { viewerHtml } from '../viewer';
import { Btn, C, Card, Chip, Icon, Tile } from '../ui';
const IC: Record<string, [string, string]> = {
  'Edit PDF': ['pencil', C.blue], Merge: ['call-merge', C.red], 'Split all': ['call-split', C.orange], Extract: ['file-export', C.green], Delete: ['file-remove', C.red],
  Rotate: ['rotate-right', C.teal], Reorder: ['swap-vertical', C.purple], Reverse: ['sort-reverse-variant', C.blue], 'Page numbers': ['format-list-numbered', C.green],
  Watermark: ['water', C.teal], 'Header & footer': ['page-layout-header-footer', C.orange], Crop: ['crop', C.pink], 'Insert blank': ['file-plus', C.green],
  Metadata: ['tag-text', C.purple], Compress: ['zip-box', C.red], 'Images → PDF': ['image-multiple', C.blue] };
const dir = (n: string) => { const d = new Directory(Paths.document, n); if (!d.exists) d.create(); return d; };
const listAll = () => ['files', 'outputs'].flatMap(n => dir(n).list()).filter((x: any) => x instanceof File)
  .map((x: any) => ({ uri: x.uri as string, name: x.name as string, size: (x.size ?? 0) as number, t: (x.lastModified ?? 0) as number })).sort((a, b) => b.t - a.t);
const kb = (n: number) => (n < 10240 ? (n / 1024).toFixed(1) : Math.round(n / 1024)) + ' KB';
const isPdf = (n: string) => /\.pdf$/i.test(n);
async function applyEdits(uri: string, ann: any[]) {
  const d = await PDFDocument.load(await new File(uri).bytes(), { updateMetadata: false }), f = await d.embedFont(StandardFonts.Helvetica);
  const col = (h: string) => rgb(parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255);
  for (const a of ann) {
    const pg = d.getPage(a.p);
    if (a.t === 'text') pg.drawText(a.txt, { x: a.x, y: a.y, size: a.s, font: f, color: col(a.c) });
    else for (let i = 1; i < a.pts.length; i++) pg.drawLine({ start: { x: a.pts[i - 1][0], y: a.pts[i - 1][1] }, end: { x: a.pts[i][0], y: a.pts[i][1] }, thickness: a.w, color: col(a.c), opacity: a.t === 'hl' ? 0.35 : 1, lineCap: LineCapStyle.Round });
  }
  d.setProducer(CREDIT); d.setCreator(CREDIT);
  return save(`edited-${Date.now()}.pdf`, await d.save());
}
const Act = ({ i, t, c, onPress }: { i: string; t: string; c: string; onPress: () => void }) => (
  <Pressable onPress={onPress} style={{ flex: 1, alignItems: 'center', paddingVertical: 8 }}>
    <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: c, alignItems: 'center', justifyContent: 'center' }}><Icon n={i} /></View>
    <Text style={{ color: '#fff', fontSize: 11, marginTop: 4 }}>{t}</Text></Pressable>);
type V = { uri: string; name: string; edit: boolean };
function Viewer({ v, onClose, onSaved }: { v: V; onClose: () => void; onSaved: (u: string) => void }) {
  const ref = useRef<WebView>(null); const [edit, setEdit] = useState(v.edit); const [ready, setReady] = useState(false);
  const html = useMemo(() => viewerHtml(), []);
  const load = async () => { const b64 = await new File(v.uri).base64(); ref.current?.injectJavaScript(`openPdf(${JSON.stringify(b64)});setEdit(${edit});true;`); };
  const toggle = () => { const n = !edit; setEdit(n); ref.current?.injectJavaScript(`setEdit(${n});true;`); };
  const onMsg = async (e: any) => {
    const m = JSON.parse(e.nativeEvent.data);
    if (m.t === 'ready') setReady(true);
    if (m.t === 'ann') {
      if (!m.ann.length) return Alert.alert('Nothing to save', 'Draw, highlight or add text first.');
      try { onSaved(await applyEdits(v.uri, m.ann)); } catch (x: any) { Alert.alert('Could not save edits', x.message); }
    }
  };
  return (<Modal visible animationType="slide" onRequestClose={onClose}>
    <View style={{ flex: 1, backgroundColor: C.ink }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: edit ? C.blue : C.red }}>
        <Text numberOfLines={1} style={{ flex: 1, color: '#fff', fontWeight: '700' }}>{edit ? 'Editing · ' : ''}{v.name}</Text>
        <Pressable onPress={onClose}><Icon n="close" s={26} /></Pressable></View>
      <WebView ref={ref} originWhitelist={['*']} source={{ html, baseUrl: 'https://localhost/' }} onLoadEnd={load} onMessage={onMsg} style={{ flex: 1 }} />
      {!ready ? <ActivityIndicator color="#fff" style={{ position: 'absolute', top: '50%', alignSelf: 'center' }} /> : null}
      <View style={{ flexDirection: 'row', backgroundColor: '#1d2330', paddingBottom: 10 }}>
        <Act i={edit ? 'eye' : 'pencil'} t={edit ? 'View' : 'Edit'} c={C.blue} onPress={toggle} />
        {edit ? <Act i="content-save" t="Save edits" c={C.orange} onPress={() => ref.current?.injectJavaScript('getAnn();true;')} /> : null}
        <Act i="download" t="Download" c={C.green} onPress={() => download(v.uri, v.name)} />
        <Act i="share-variant" t="Share" c="#6B7280" onPress={() => share(v.uri)} /></View></View></Modal>);
}
export default function PdfTools() {
  const { tool } = useLocalSearchParams<{ tool?: string }>();
  const names = ['Edit PDF', ...TOOLS.map((x: any) => x.n)];
  const [ti, setTi] = useState(tool === 'edit' ? 0 : 1); const [files, setFiles] = useState<any[]>([]); const [sel, setSel] = useState<string[]>([]);
  const [o, setO] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false); const [view, setView] = useState<V | null>(null);
  const refresh = () => setFiles(listAll()); useEffect(() => { refresh(); }, []);
  const t: any = ti === 0 ? null : TOOLS[ti - 1]; const [icon, color] = IC[names[ti]] ?? ['file', C.red];
  const toggle = (u: string) => setSel(s => (s.includes(u) ? s.filter(x => x !== u) : [...s, u]));
  const add = async () => {
    try {
      const r = await DP.getDocumentAsync({ type: ['application/pdf', 'image/jpeg', 'image/png'], multiple: true, copyToCacheDirectory: true }); if (r.canceled) return;
      const d = dir('files');
      for (const a of r.assets) { const f = new File(d, a.name); if (f.exists) f.delete(); await new File(a.uri).copy(f); }
      refresh();
    } catch (e: any) { Alert.alert('Could not add files', e.message); }
  };
  const del = (u: string) => { try { new File(u).delete(); } catch {} setSel(s => s.filter(x => x !== u)); refresh(); };
  const run = async () => {
    try {
      const chosen = sel.map(u => files.find(x => x.uri === u)).filter(Boolean) as any[];
      if (ti === 0) { const p = chosen.find(x => isPdf(x.name)); if (!p) throw Error('Tick a PDF in "Your files" first.'); return setView({ uri: p.uri, name: p.name, edit: true }); }
      const want = t.img ? chosen.filter(x => !isPdf(x.name)) : chosen.filter(x => isPdf(x.name));
      if (!want.length) throw Error(t.img ? 'Tick one or more pictures first.' : 'Tick a PDF in "Your files" first.');
      if (t.n === 'Merge' && want.length < 2) throw Error('Tick at least two PDFs to merge.');
      setBusy(true);
      const inp = await Promise.all((t.m ? want : want.slice(0, 1)).map(async (x: any) => ({ b: await new File(x.uri).bytes(), n: x.name })));
      const opts: Record<string, string> = {}; (t.o ?? []).forEach(([k, , d]: string[]) => { opts[k] = o[k] ?? d; });
      const out: string[] = [];
      for (const [d, n] of await t.run(inp, opts)) { d.setProducer(CREDIT); d.setCreator(CREDIT); out.push(save(n, await d.save({ useObjectStreams: true }))); }
      refresh(); setSel(out); setView({ uri: out[0], name: out[0].split('/').pop() as string, edit: false });
      if (out.length > 1) Alert.alert('Done', `${out.length} files were added to Your files.`);
    } catch (e: any) { Alert.alert('Could not finish', e.message); } finally { setBusy(false); }
  };
  return (<ScrollView contentContainerStyle={{ padding: 16 }}>
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}><Text style={{ flex: 1, fontWeight: '800', fontSize: 17, color: C.ink }}>Your files</Text>
        <Pressable onPress={add} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.blue, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 8 }}><Icon n="plus" /><Text style={{ color: '#fff', fontWeight: '700' }}>Add files</Text></Pressable></View>
      {files.length === 0 ? <Text style={{ color: C.mute, marginTop: 10 }}>Add your PDFs or pictures once. After that everything happens inside the app: tick files, run a tool, preview and edit the result.</Text> : null}
      {files.map(f => { const n = sel.indexOf(f.uri) + 1; return (
        <Pressable key={f.uri} onPress={() => toggle(f.uri)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderTopWidth: 1, borderColor: C.line, marginTop: 8 }}>
          <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: isPdf(f.name) ? C.red : C.teal, alignItems: 'center', justifyContent: 'center' }}><Icon n={isPdf(f.name) ? 'file-pdf-box' : 'file-image'} s={26} /></View>
          <View style={{ flex: 1, marginHorizontal: 10 }}><Text numberOfLines={1} style={{ fontWeight: '600', color: C.ink }}>{f.name}</Text><Text style={{ color: C.mute, fontSize: 12 }}>{kb(f.size)}</Text></View>
          <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: n ? C.green : '#E8ECF5', alignItems: 'center', justifyContent: 'center', marginRight: 8 }}>{n ? <Text style={{ color: '#fff', fontWeight: '800' }}>{n}</Text> : null}</View>
          {isPdf(f.name) ? <Pressable onPress={() => setView({ uri: f.uri, name: f.name, edit: false })} style={{ padding: 6 }}><Icon n="eye" c={C.blue} s={22} /></Pressable> : null}
          <Pressable onPress={() => del(f.uri)} style={{ padding: 6 }}><Icon n="trash-can-outline" c={C.mute} s={22} /></Pressable></Pressable>); })}
    </Card>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
      {names.map((n, i) => <Tile key={n} icon={IC[n]?.[0] ?? 'file'} label={n} color={IC[n]?.[1] ?? C.red} on={i === ti} onPress={() => { setTi(i); setO({}); }} />)}
      {Array((3 - (names.length % 3)) % 3).fill(0).map((_, i) => <View key={'f' + i} style={{ width: '30.5%' }} />)}</View>
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: color, alignItems: 'center', justifyContent: 'center' }}><Icon n={icon} /></View>
        <Text style={{ fontWeight: '800', fontSize: 17, color: C.ink }}>{names[ti]}</Text></View>
      <Text style={{ color: C.mute, marginTop: 8 }}>{ti === 0 ? 'Draw, highlight or add text on the ticked PDF, then save and download it.' : t.d}</Text>
      {(t?.o ?? []).map(([k, l, d, ch]: any) => (<View key={k + ti} style={{ marginTop: 10 }}><Text style={{ color: C.ink, fontWeight: '600' }}>{l}</Text>
        {ch ? <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 }}>{ch.map((x: string) => <Chip key={x} t={x} color={color} on={(o[k] ?? d) === x} onPress={() => setO(p => ({ ...p, [k]: x }))} />)}</View>
          : <TextInput value={o[k] ?? d} onChangeText={v => setO(p => ({ ...p, [k]: v }))} style={{ borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 10, marginTop: 4, backgroundColor: '#fff' }} />}</View>))}
      <Btn t={busy ? 'Working…' : ti === 0 ? 'Open editor' : `Run ${names[ti]}`} icon={ti === 0 ? 'pencil' : 'play'} color={color} off={busy} onPress={run} />
    </Card>
    {view ? <Viewer key={view.uri + view.edit} v={view} onClose={() => setView(null)} onSaved={u => { refresh(); setSel([u]); setView({ uri: u, name: u.split('/').pop() as string, edit: false }); }} /> : null}
  </ScrollView>);
}
