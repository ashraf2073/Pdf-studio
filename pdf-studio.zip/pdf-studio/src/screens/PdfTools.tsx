import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, ScrollView, Share, Text, TextInput, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as DP from 'expo-document-picker';
import * as IP from 'expo-image-picker';
import { Directory, File, Paths } from 'expo-file-system';
import { PDFDocument } from 'pdf-lib';
import { TOOLS } from '../tools';
import { T2, Out, applyObjs, fromB64, mimeOf, toB64 } from '../tools2';
import { CATALOG, CATCOL, CATS, Entry } from '../catalog';
import { CREDIT, save, share } from '../lib';
import { download } from '../download';
import { viewerHtml } from '../viewer';
import { engineHtml } from '../engine';
import { C, Card, Chip, Icon } from '../ui';
const dir = (n: string) => { const d = new Directory(Paths.document, n); if (!d.exists) d.create(); return d; };
const listAll = () => ['files', 'outputs'].flatMap(n => dir(n).list()).filter((x: any) => x instanceof File)
  .map((x: any) => ({ uri: x.uri as string, name: x.name as string, size: (x.size ?? 0) as number, t: (x.lastModified ?? 0) as number })).sort((a, b) => b.t - a.t);
const kb = (n: number) => (n < 10240 ? (n / 1024).toFixed(1) : Math.round(n / 1024)) + ' KB';
const isPdf = (n: string) => /\.pdf$/i.test(n);
const isImg = (n: string) => /\.(jpe?g|png|webp|heic|heif|gif|bmp|svg|avif)$/i.test(n);
const rowIcon = (n: string): [string, string] => (isPdf(n) ? ['file-pdf-box', C.red] : isImg(n) ? ['file-image', C.teal] : ['file-document-outline', C.purple]);
const meta = (e: Entry) => { const t: any = e.k === 'lib' ? TOOLS.find((x: any) => x.n === e.r) : null; return { d: e.d ?? t?.d ?? '', o: (e.o ?? t?.o ?? []) as [string, string, string, string[]?][], m: !!(e.m ?? t?.m), img: !!(e.img ?? t?.img), t }; };
function useEngine() {
  const [on, setOn] = useState(false); const ref = useRef<WebView>(null); const waits = useRef<Record<string, any>>({}); const rdy = useRef<(() => void)[]>([]); const up = useRef(false);
  const html = useMemo(() => (on ? engineHtml() : ''), [on]);
  const onMsg = (ev: any) => {
    const m = JSON.parse(ev.nativeEvent.data);
    if (m.t === 'ready') { up.current = true; rdy.current.splice(0).forEach(f => f()); return; }
    const w = waits.current[m.id]; if (!w) return;
    if (m.t === 'part') w.parts.push(m); else { delete waits.current[m.id]; if (m.t === 'done') w.res({ data: m.data, parts: w.parts }); else w.rej(new Error(m.msg)); }
  };
  const call = async (op: string, a: any) => {
    setOn(true); if (!up.current) await new Promise<void>(r => rdy.current.push(r));
    return new Promise<any>((res, rej) => { const id = Math.random().toString(36).slice(2); waits.current[id] = { res, rej, parts: [] };
      ref.current?.injectJavaScript(`run(${JSON.stringify(id)},${JSON.stringify(op)},${JSON.stringify(a)});true;`); });
  };
  const view = on ? <WebView ref={ref} originWhitelist={['*']} source={{ html, baseUrl: 'https://localhost/' }} onMessage={onMsg} pointerEvents="none" style={{ position: 'absolute', width: 1, height: 1, opacity: 0 }} /> : null;
  return { call, view };
}
const Top = ({ i, t, onPress }: { i: string; t: string; onPress: () => void }) => (
  <Pressable onPress={onPress} style={{ alignItems: 'center', paddingHorizontal: 8 }}><Icon n={i} s={22} /><Text style={{ color: '#fff', fontSize: 10 }}>{t}</Text></Pressable>);
type V = { uri: string; name: string; edit: boolean; preset?: string };
function Viewer({ v, onClose, onSaved }: { v: V; onClose: () => void; onSaved: (u: string) => void }) {
  const ref = useRef<WebView>(null); const [edit, setEdit] = useState(v.edit); const [ready, setReady] = useState(false);
  const html = useMemo(() => viewerHtml(), []); const pre = JSON.stringify(v.preset ?? 'text');
  const load = async () => { const b64 = await new File(v.uri).base64(); ref.current?.injectJavaScript(`openPdf(${JSON.stringify(b64)}).then(function(){setEdit(${edit},${pre})});true;`); };
  const toggle = () => { const n = !edit; setEdit(n); ref.current?.injectJavaScript(`setEdit(${n},${pre});true;`); };
  const onMsg = async (e: any) => {
    const m = JSON.parse(e.nativeEvent.data);
    if (m.t === 'ready') setReady(true);
    if (m.t === 'ann') {
      if (!m.objs.length) return Alert.alert('Nothing to save', 'Add some text, a drawing or a signature first.');
      try { const d = await PDFDocument.load(await new File(v.uri).bytes(), { updateMetadata: false }); await applyObjs(d, m.objs); d.setProducer(CREDIT); d.setCreator(CREDIT); onSaved(save(`edited-${Date.now()}.pdf`, await d.save())); }
      catch (x: any) { Alert.alert('Could not save edits', x.message); }
    }
  };
  return (<Modal visible animationType="slide" onRequestClose={onClose}>
    <View style={{ flex: 1, backgroundColor: C.ink }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: edit ? C.blue : C.red, paddingHorizontal: 8, paddingVertical: 8 }}>
        <Pressable onPress={onClose} style={{ padding: 6 }}><Icon n="close" s={26} /></Pressable>
        <Text numberOfLines={1} style={{ flex: 1, color: '#fff', fontWeight: '700', marginHorizontal: 6 }}>{v.name}</Text>
        <Top i={edit ? 'eye' : 'pencil'} t={edit ? 'View' : 'Edit'} onPress={toggle} />
        {edit ? <Top i="content-save" t="Save" onPress={() => ref.current?.injectJavaScript('getAnn();true;')} /> : null}
        <Top i="download" t="Download" onPress={() => download(v.uri, v.name)} />
        <Top i="share-variant" t="Share" onPress={() => share(v.uri)} /></View>
      <WebView ref={ref} originWhitelist={['*']} source={{ html, baseUrl: 'https://localhost/' }} onLoadEnd={load} onMessage={onMsg} keyboardDisplayRequiresUserAction={false} style={{ flex: 1 }} />
      {!ready ? <ActivityIndicator color="#fff" size="large" style={{ position: 'absolute', top: '50%', alignSelf: 'center' }} /> : null}
    </View></Modal>);
}
const ToolTile = ({ e, onPress }: { e: Entry; onPress: () => void }) => {
  const lock = e.k === 'lock';
  return (<Pressable onPress={onPress} style={{ width: '48%', backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: C.line, padding: 12, marginBottom: 12, alignItems: 'center', opacity: lock ? 0.55 : 1 }}>
    <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: CATCOL[e.cat], alignItems: 'center', justifyContent: 'center' }}><Icon n={e.ic} s={30} /></View>
    <Text style={{ marginTop: 8, fontWeight: '700', color: C.ink, textAlign: 'center', fontSize: 13 }}>{e.n}</Text>
    {lock ? <View style={{ position: 'absolute', top: 8, right: 8 }}><Icon n="lock" c={C.mute} s={16} /></View> : null}</Pressable>);
};
export default function PdfTools() {
  const { tool } = useLocalSearchParams<{ tool?: string }>(); const router = useRouter(); const eng = useEngine();
  const [files, setFiles] = useState<any[]>([]); const [sel, setSel] = useState<string[]>([]); const [cat, setCat] = useState(tool === 'edit' ? 'Edit' : 'Frequently used'); const [q, setQ] = useState('');
  const [sheet, setSheet] = useState<Entry | null>(null); const [o, setO] = useState<Record<string, string>>({}); const [busy, setBusy] = useState('');
  const [view, setView] = useState<V | null>(null); const [text, setText] = useState<{ t: string; b: string } | null>(null);
  const refresh = () => setFiles(listAll()); useEffect(() => { refresh(); }, []);
  const chosen = () => sel.map(u => files.find(x => x.uri === u)).filter(Boolean) as any[];
  const firstPdf = () => chosen().find(x => isPdf(x.name));
  const toggle = (u: string) => setSel(s => (s.includes(u) ? s.filter(x => x !== u) : [...s, u]));
  const open = (u: string) => setView({ uri: u, name: u.split('/').pop() as string, edit: false });
  const add = async () => {
    try {
      const r = await DP.getDocumentAsync({ type: ['application/pdf', 'image/*'], multiple: true, copyToCacheDirectory: true }); if (r.canceled) return;
      const d = dir('files');
      for (const a of r.assets) { const f = new File(d, a.name); if (f.exists) f.delete(); await new File(a.uri).copy(f); }
      refresh();
    } catch (e: any) { Alert.alert('Could not add files', e.message); }
  };
  const del = (u: string) => { try { new File(u).delete(); } catch {} setSel(s => s.filter(x => x !== u)); refresh(); };
  const special = async (e: Entry) => {
    const r = e.r;
    if (r === 'qr') return router.push('/qr' as any);
    if (r === 'cv') return router.push('/cv' as any);
    if (r === 'pwd') { const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*'; let p = ''; for (let i = 0; i < 16; i++) p += ch[Math.floor(Math.random() * ch.length)]; return Alert.alert('Your new password', p, [{ text: 'Share', onPress: () => Share.share({ message: p }) }, { text: 'Close' }]); }
    if (r === 'print') { const p = firstPdf(); if (!p) throw Error('Tick a PDF in Your files first.'); return Alert.alert('Print', 'In the next screen choose Print.', [{ text: 'OK', onPress: () => share(p.uri) }]); }
    if (r === 'camera') {
      const perm = await IP.requestCameraPermissionsAsync(); if (!perm.granted) throw Error('Camera permission is needed to scan a page.');
      const res = await IP.launchCameraAsync({ mediaTypes: ['images'], quality: 0.8 }); if (res.canceled) return;
      setBusy('Making your PDF…');
      const tl: any = TOOLS.find((x: any) => x.n === 'Images → PDF'); const [[d]] = await tl.run([{ b: await new File(res.assets[0].uri).bytes(), n: 'scan.jpg' }], { s: 'A4' });
      d.setProducer(CREDIT); d.setCreator(CREDIT); const u = save('scan-' + Date.now() + '.pdf', await d.save()); refresh(); setSel([u]); open(u);
    }
  };
  const tap = async (e: Entry) => {
    try {
      if (e.k === 'lock') return Alert.alert('Needs an online converter', `${e.n} can't be done offline inside this app.`);
      if (e.k === 'edit') { const p = firstPdf(); if (!p) throw Error('Tick a PDF in Your files first.'); return setView({ uri: p.uri, name: p.name, edit: true, preset: e.r }); }
      if (e.k === 'sp') return await special(e);
      setO({}); setSheet(e);
    } catch (x: any) { Alert.alert('Hmm', x.message); } finally { setBusy(''); }
  };
  const exec = async (e: Entry) => {
    try {
      const mt = meta(e), want = chosen().filter(x => (mt.img ? isImg(x.name) : isPdf(x.name)));
      if (e.r !== 'write' && !want.length) throw Error(mt.img ? 'Tick one or more pictures in Your files first.' : 'Tick a PDF in Your files first.');
      if (e.r === 'Merge' && want.length < 2) throw Error('Tick at least two PDFs to merge.');
      setSheet(null); setBusy('Working…');
      let inp = await Promise.all((mt.m ? want : want.slice(0, 1)).map(async x => ({ b: await new File(x.uri).bytes(), n: x.name })));
      if (mt.img && e.r !== 'imgconv') inp = await Promise.all(inp.map(async f => (f.b[0] === 0xff || f.b[0] === 0x89 ? f : { n: f.n, b: fromB64((await eng.call('img', { b64: toB64(f.b), mime: mimeOf(f.n), fmt: 'jpg' })).data) })));
      const opts: Record<string, string> = { x: e.x ?? '' }; mt.o.forEach(([k, , d]) => { opts[k] = o[k] ?? d; });
      const outs: Out[] = mt.t ? (await mt.t.run(inp, opts)).map(([d, n]: any) => ({ name: n, doc: d })) : await T2[e.r as string](inp, opts, eng);
      const saved: string[] = []; let show = '';
      for (const x of outs) {
        if (x.show) show += x.show;
        else if (x.doc) { if (!x.keep) { x.doc.setProducer(CREDIT); x.doc.setCreator(CREDIT); } saved.push(save(x.name, await x.doc.save({ useObjectStreams: true }))); }
        else if (x.b64) saved.push(save(x.name, x.b64, true)); else if (x.text != null) saved.push(save(x.name, x.text));
      }
      refresh(); if (show) setText({ t: e.n, b: show });
      if (saved.length) { setSel(saved); if (isPdf(saved[0])) open(saved[0]); else Alert.alert('Done', `${saved.length} file(s) added to Your files. Tap the download icon to keep them.`); }
    } catch (x: any) { Alert.alert('Could not finish', x.message); } finally { setBusy(''); }
  };
  const ql = q.trim().toLowerCase();
  const list = ql ? CATALOG.filter(x => x.n.toLowerCase().includes(ql)) : cat === 'Frequently used' ? CATALOG.filter(x => x.fav) : CATALOG.filter(x => x.cat === cat);
  const mt = sheet ? meta(sheet) : null;
  const ticked = mt ? chosen().filter(x => (mt.img ? isImg(x.name) : isPdf(x.name))).length : 0;
  return (<View style={{ flex: 1 }}>
    <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}><Text style={{ flex: 1, fontWeight: '800', fontSize: 17, color: C.ink }}>Your files</Text>
          <Pressable onPress={add} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.blue, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 8 }}><Icon n="plus" /><Text style={{ color: '#fff', fontWeight: '700' }}>Add files</Text></Pressable></View>
        {files.length === 0 ? <Text style={{ color: C.mute, marginTop: 10 }}>Add your PDFs or pictures once. After that everything happens inside the app: tick files, pick a tool, preview and edit the result.</Text> : null}
        {files.map(f => { const n = sel.indexOf(f.uri) + 1, [ic, col] = rowIcon(f.name); return (
          <Pressable key={f.uri} onPress={() => toggle(f.uri)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderTopWidth: 1, borderColor: C.line, marginTop: 8 }}>
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: col, alignItems: 'center', justifyContent: 'center' }}><Icon n={ic} s={26} /></View>
            <View style={{ flex: 1, marginHorizontal: 10 }}><Text numberOfLines={1} style={{ fontWeight: '600', color: C.ink }}>{f.name}</Text><Text style={{ color: C.mute, fontSize: 12 }}>{kb(f.size)}</Text></View>
            <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: n ? C.green : '#E8ECF5', alignItems: 'center', justifyContent: 'center', marginRight: 4 }}>{n ? <Text style={{ color: '#fff', fontWeight: '800' }}>{n}</Text> : null}</View>
            {isPdf(f.name) ? <Pressable onPress={() => open(f.uri)} style={{ padding: 6 }}><Icon n="eye" c={C.blue} s={22} /></Pressable> : null}
            <Pressable onPress={() => download(f.uri, f.name, mimeOf(f.name))} style={{ padding: 6 }}><Icon n="download" c={C.green} s={22} /></Pressable>
            <Pressable onPress={() => del(f.uri)} style={{ padding: 6 }}><Icon n="trash-can-outline" c={C.mute} s={22} /></Pressable></Pressable>); })}
      </Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: C.line, paddingHorizontal: 12, marginBottom: 10 }}>
        <Icon n="magnify" c={C.mute} s={22} /><TextInput value={q} onChangeText={setQ} placeholder="Search all tools (merge, jpg, rotate…)" style={{ flex: 1, padding: 10 }} /></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>{CATS.map(c => <Chip key={c} t={c} on={!ql && cat === c} color={CATCOL[c]} onPress={() => { setQ(''); setCat(c); }} />)}</ScrollView>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
        {list.map(x => <ToolTile key={x.id + (ql ? 's' : cat)} e={x} onPress={() => tap(x)} />)}{list.length % 2 ? <View style={{ width: '48%' }} /> : null}</View>
      {!list.length ? <Text style={{ color: C.mute, textAlign: 'center' }}>No tool found.</Text> : null}
    </ScrollView>
    {sheet && mt ? (<Modal visible transparent animationType="slide" onRequestClose={() => setSheet(null)}>
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,.45)' }}>
        <View style={{ backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 18, maxHeight: '85%' }}>
          <ScrollView keyboardShouldPersistTaps="handled">
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: CATCOL[sheet.cat], alignItems: 'center', justifyContent: 'center' }}><Icon n={sheet.ic} s={28} /></View>
              <Text style={{ flex: 1, fontWeight: '800', fontSize: 18, color: C.ink }}>{sheet.n}</Text><Pressable onPress={() => setSheet(null)}><Icon n="close" c={C.mute} s={24} /></Pressable></View>
            {mt.d ? <Text style={{ color: C.mute, marginTop: 10 }}>{mt.d}</Text> : null}
            {sheet.r !== 'write' ? <Text style={{ marginTop: 10, fontWeight: '600', color: ticked ? C.green : C.red }}>{ticked ? `${ticked} ${mt.img ? 'picture' : 'PDF'}${ticked > 1 ? 's' : ''} ticked` : `Tick ${mt.m ? 'one or more' : 'one'} ${mt.img ? 'picture' : 'PDF'}${mt.m ? 's' : ''} in Your files first`}</Text> : null}
            {mt.o.map(([k, l, d, ch]) => (<View key={k} style={{ marginTop: 12 }}><Text style={{ color: C.ink, fontWeight: '600' }}>{l}</Text>
              {ch ? <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 }}>{ch.map(x => <Chip key={x} t={x} color={CATCOL[sheet.cat]} on={(o[k] ?? d) === x} onPress={() => setO(p => ({ ...p, [k]: x }))} />)}</View>
                : <TextInput value={o[k] ?? d} onChangeText={v => setO(p => ({ ...p, [k]: v }))} multiline={k === 't'} style={{ borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 10, marginTop: 4, minHeight: k === 't' ? 90 : undefined, backgroundColor: '#fff' }} />}</View>))}
            <Pressable onPress={() => exec(sheet)} style={{ backgroundColor: CATCOL[sheet.cat], borderRadius: 14, paddingVertical: 14, marginTop: 16, alignItems: 'center' }}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 16 }}>Run</Text></Pressable>
          </ScrollView></View></View></Modal>) : null}
    {text ? (<Modal visible animationType="slide" onRequestClose={() => setText(null)}><View style={{ flex: 1, backgroundColor: '#fff' }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: C.blue, padding: 12 }}><Text style={{ flex: 1, color: '#fff', fontWeight: '800', fontSize: 16 }}>{text.t}</Text>
        <Pressable onPress={() => Share.share({ message: text.b })} style={{ padding: 6 }}><Icon n="share-variant" /></Pressable><Pressable onPress={() => setText(null)} style={{ padding: 6 }}><Icon n="close" s={26} /></Pressable></View>
      <ScrollView contentContainerStyle={{ padding: 16 }}><Text selectable style={{ color: C.ink, lineHeight: 22 }}>{text.b}</Text></ScrollView></View></Modal>) : null}
    {view ? <Viewer key={view.uri + view.edit} v={view} onClose={() => setView(null)} onSaved={u => { refresh(); setSel([u]); open(u); }} /> : null}
    {busy ? (<View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: 'rgba(20,24,31,.6)', alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator size="large" color="#fff" /><Text style={{ color: '#fff', marginTop: 12, fontWeight: '700' }}>{busy}</Text></View>) : null}
    {eng.view}
  </View>);
}
