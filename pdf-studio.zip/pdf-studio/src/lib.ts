import { PDFDocument, StandardFonts, degrees, rgb } from 'pdf-lib';
import { Directory, File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import qrcode from 'qrcode-generator';
qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
export const CREDIT = 'Made par Ashraf';
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
export const save = (name: string, data: Uint8Array | string, b64 = false) => {
  const d = new Directory(Paths.document, 'outputs'); if (!d.exists) d.create();
  const f = new File(d, name); if (f.exists) f.delete(); f.create();
  b64 ? f.write(data as string, { encoding: 'base64' }) : f.write(data); return f.uri;
};
export const share = async (uri: string, mimeType = 'application/pdf') => {
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType });
};
const load = async (u: string) => PDFDocument.load(await new File(u).bytes(), { updateMetadata: false });
const done = async (d: PDFDocument, n: string) => {
  d.setProducer(CREDIT); d.setCreator(CREDIT); return save(`${n}-${stamp()}.pdf`, await d.save({ useObjectStreams: true }));
};
export function ranges(spec: string, total: number) {
  const out: number[] = [];
  for (const t of spec.split(',').map(s => s.trim()).filter(Boolean)) {
    const m = t.match(/^(\d*)\s*-\s*(\d*)$/); let a: number, b: number;
    if (m) { a = m[1] ? +m[1] : 1; b = m[2] ? +m[2] : total; } else if (/^\d+$/.test(t)) a = b = +t; else throw new Error(`Bad range "${t}"`);
    if (a < 1 || b > total || a > b) throw new Error(`"${t}" is outside 1-${total}`);
    for (let i = a; i <= b; i++) out.push(i - 1);
  }
  if (!out.length) throw new Error('Enter pages, e.g. 1-3,5'); return out;
}
const pick = async (uri: string, idx: number[], n: string) => {
  const s = await load(uri), o = await PDFDocument.create();
  (await o.copyPages(s, idx)).forEach(p => o.addPage(p)); return done(o, n);
};
export async function merge(uris: string[]) {
  const o = await PDFDocument.create();
  for (const u of uris) { const s = await load(u); (await o.copyPages(s, s.getPageIndices())).forEach(p => o.addPage(p)); }
  return done(o, 'merged');
}
export const extract = async (u: string, spec: string) => pick(u, ranges(spec, (await load(u)).getPageCount()), 'extract');
export async function remove(u: string, spec: string) {
  const n = (await load(u)).getPageCount(), del = new Set(ranges(spec, n));
  const keep = [...Array(n).keys()].filter(i => !del.has(i)); if (!keep.length) throw new Error('Cannot delete every page');
  return pick(u, keep, 'edited');
}
export async function rotate(u: string, spec: string, by = 90) {
  const d = await load(u); ranges(spec, d.getPageCount()).forEach(i => { const p = d.getPage(i); p.setRotation(degrees((p.getRotation().angle + by) % 360)); });
  return done(d, 'rotated');
}
export async function numbers(u: string) {
  const d = await load(u), f = await d.embedFont(StandardFonts.Helvetica), ps = d.getPages();
  ps.forEach((p, i) => { const t = `Page ${i + 1} of ${ps.length}`; p.drawText(t, { x: (p.getWidth() - f.widthOfTextAtSize(t, 10)) / 2, y: 24, size: 10, font: f, color: rgb(.3, .3, .3) }); });
  return done(d, 'numbered');
}
export async function watermark(u: string, text: string) {
  const d = await load(u), f = await d.embedFont(StandardFonts.HelveticaBold), w = f.widthOfTextAtSize(text, 48), r = Math.PI / 4;
  d.getPages().forEach(p => p.drawText(text, { x: p.getWidth() / 2 - w / 2 * Math.cos(r), y: p.getHeight() / 2 - w / 2 * Math.sin(r), size: 48, font: f, color: rgb(.5, .5, .5), opacity: .18, rotate: degrees(45) }));
  return done(d, 'watermarked');
}
export const compress = async (u: string) => done(await load(u), 'compressed');
export async function imagesToPdf(uris: string[]) {
  const d = await PDFDocument.create(), A: [number, number] = [595.28, 841.89];
  for (const u of uris) {
    const b = await new File(u).bytes(), im = b[0] === 0x89 ? await d.embedPng(b) : await d.embedJpg(b);
    const [pw, ph] = im.width > im.height ? [A[1], A[0]] : A, s = im.scale(Math.min((pw - 48) / im.width, (ph - 48) / im.height));
    d.addPage([pw, ph]).drawImage(im, { x: (pw - s.width) / 2, y: (ph - s.height) / 2, width: s.width, height: s.height });
  }
  return done(d, 'images');
}
// ---- QR ----
export type Kind = 'url' | 'text' | 'vcard' | 'phone' | 'sms' | 'wifi' | 'pdf';
const need = (v = '', l: string) => { if (!v.trim()) throw new Error(`${l} is required`); return v.trim(); };
const ve = (s = '') => s.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/([,;])/g, '\\$1'), we = (s = '') => s.replace(/([\\;,:"])/g, '\\$1'), dg = (s: string) => s.replace(/[^\d+]/g, '');
export function payload(k: Kind, f: Record<string, string>) {
  switch (k) {
    case 'url': case 'pdf': { const r = need(f.v, 'Link'); return /^[a-z][a-z0-9+.-]*:/i.test(r) ? r : `https://${r}`; }
    case 'text': return need(f.v, 'Text');
    case 'phone': return `tel:${dg(need(f.phone, 'Phone'))}`;
    case 'sms': return `SMSTO:${dg(need(f.phone, 'Phone'))}:${f.msg ?? ''}`;
    case 'wifi': return `WIFI:T:${f.pass ? 'WPA' : 'nopass'};S:${we(need(f.ssid, 'Network name'))};${f.pass ? `P:${we(f.pass)};` : ''}H:false;;`;
    case 'vcard': return ['BEGIN:VCARD', 'VERSION:3.0', `N:${ve(f.last)};${ve(need(f.first, 'First name'))};;;`, `FN:${ve(`${f.first} ${f.last ?? ''}`.trim())}`,
      f.org && `ORG:${ve(f.org)}`, f.phone && `TEL;TYPE=CELL:${dg(f.phone)}`, f.email && `EMAIL:${ve(f.email)}`, f.url && `URL:${ve(f.url)}`, 'END:VCARD'].filter(Boolean).join('\r\n');
  }
}
export function qr(text: string, ec: 'M' | 'H' = 'M') {
  const q = qrcode(0, ec); q.addData(text, 'Byte'); q.make(); const n = q.getModuleCount(); let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + 4} ${r + 4}h1v1h-1z`;
  return { d, u: n + 8 };
}
export const qrSvg = (x: { d: string; u: number }, fg: string, bg: string, size = 1024) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${x.u} ${x.u}" width="${size}" height="${size}" shape-rendering="crispEdges"><rect width="${x.u}" height="${x.u}" fill="${bg}"/><path d="${x.d}" fill="${fg}"/></svg>`;
