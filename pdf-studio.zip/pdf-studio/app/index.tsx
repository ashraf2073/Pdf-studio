import { ScrollView, Text } from 'react-native';
import { Link } from 'expo-router';
import { CREDIT } from '../src/lib';
const T = [['/pdf-tools', 'PDF tools', 'Merge, split, rotate, compress, watermark'], ['/cv', 'CV builder', '3 ATS-friendly templates + live preview'], ['/qr', 'QR generator', 'Link, contact, Wi-Fi, SMS, PDF']] as const;
export default function Home() {
  return (<ScrollView contentContainerStyle={{ padding: 20, gap: 12 }}>
    {T.map(([h, a, b]) => (<Link key={h} href={h as any} style={{ padding: 18, borderWidth: 1, borderColor: '#ccc', borderRadius: 14 }}>
      <Text style={{ fontSize: 18, fontWeight: '700' }}>{a + '\n'}</Text><Text>{b}</Text></Link>))}
    <Text style={{ textAlign: 'center', color: '#888', marginTop: 24 }}>{CREDIT}</Text></ScrollView>);
}
