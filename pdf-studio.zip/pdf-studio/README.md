# PDF Studio - Made par Ashraf
Build: push to GitHub and run the "Build Android APK" workflow (or: npm install, npx expo install --fix, eas build -p android --profile preview).

## Free offline tools (no accounts, no internet)
Word (.docx), Excel (.xlsx/.xls/.ods), PowerPoint (.pptx), ODT, RTF and EPUB to PDF; PDF to Word (text only) and PDF to Excel (tables by layout); Protect and Unlock PDF.
They run inside the app. Word/Excel/PowerPoint conversions keep text, tables and pictures but not the exact page layout.

## Optional online converter (only for OCR, PDF/A, PDF to PowerPoint/ODT/EPUB/SVG/TIFF, TIFF to PDF)
You can ignore these tools. If you ever want them (CloudConvert free daily allowance, via Supabase):
1. cloudconvert.com -> sign up -> dashboard -> API -> API Keys -> create a key with task.read and task.write.
2. supabase.com -> new project -> Edge Functions -> Deploy a new function -> Via Editor -> paste supabase/functions/convert/index.ts -> name it `convert` -> Deploy.
3. If the function has a "Verify JWT" switch, turn it off (the app key protects it).
4. Edge Functions -> Secrets: add CLOUDCONVERT_API_KEY and APP_KEY (any secret word).
5. In the app: tap a tool with a cloud icon -> "Converter not set up yet" -> paste the Project URL and APP_KEY.
(`converter/` is an optional self-hosted server for people with their own hosting. You do not need it.)

## Notes
- First tap on any Download button asks for a folder once (pick or create Documents -> PDF Studio). Android does not allow apps to use the Downloads root.
- "Add files" uses Android's picker once; after that files live inside the app.
