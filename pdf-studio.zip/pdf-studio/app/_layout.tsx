import { Stack } from 'expo-router';
export default function L() { return <Stack screenOptions={{ headerTitleAlign: 'center' }} />; }
