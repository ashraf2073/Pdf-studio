import React, { Suspense, lazy } from 'react';
import { ActivityIndicator } from 'react-native';
import { Safe } from '../src/Safe';
const S = lazy(() => import('../src/screens/Cv'));
export default function Route() { return (<Safe><Suspense fallback={<ActivityIndicator style={{ marginTop: 40 }} />}><S /></Suspense></Safe>); }
