import { PDFDocument, StandardFonts, LineCapStyle, degrees, rgb } from 'pdf-lib';
export type In = { b: Uint8Array; n: string };
export type Out = { name: string; doc?: PDFDocument; b64?: string; text?: string; show?: string; keep?: boolean; noOpen?: boolean };
const ld = (b: Uint8Array) => PDFDocument.load(b, { updateMetadata: false });
const nm = (n: string) => n.replace(/\.[^.]+$/, '');
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
export const SIZES: Record<string, [number, number]> = { A4: [595.28, 841.89], A5: [419.53, 595.28], Letter: [612, 792], Legal: [612, 1008] };
export const toB64 = (u: Uint8Array) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, Array.from(u.subarray(i, i + 0x8000)) as any); return btoa(s); };
export const fromB64 = (b: string) => { const d = atob(b), u = new Uint8Array(d.length); for (let i = 0; i < d.length; i++) u[i] = d.charCodeAt(i); return u; };
const MIMES: Record<string, string> = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', heic: 'image/heic', heif: 'image/heif', svg: 'image/svg+xml', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif', txt: 'text/plain', md: 'text/markdown', html: 'text/html', rtf: 'application/rtf' };
export const mimeOf = (n: string) => MIMES[(n.split('.').pop() || '').toLowerCase()] ?? 'application/octet-stream';
function rngs(spec: string, total: number) {
  const out: number[] = [];
  for (const t of String(spec).split(',').map(s => s.trim()).filter(Boolean)) {
    const m = t.match(/^(\d*)\s*-\s*(\d*)$/); let a: number, b: number;
    if (m) { a = m[1] ? +m[1] : 1; b = m[2] ? +m[2] : total; } else if (/^\d+$/.test(t)) a = b = +t; else throw Error(`Bad range "${t}"`);
    if (a < 1 || b > total || a > b) throw Error(`"${t}" is outside 1-${total}`);
    for (let i = a; i <= b; i++) out.push(i - 1);
  }
  if (!out.length) throw Error('Enter pages, e.g. 1-3,5'); return out;
}
const Q: Record<string, [number, number]> = { High: [2, 0.9], Medium: [1.5, 0.7], Low: [1.1, 0.5] };
async function rebuild(parts: any[], scale: number) {
  const d = await PDFDocument.create();
  for (const p of [...parts].sort((a, b) => a.i - b.i)) { const im = await d.embedJpg(p.data), w = p.w / scale, h = p.h / scale; d.addPage([w, h]).drawImage(im, { x: 0, y: 0, width: w, height: h }); }
  return d;
}
const rtf = (s: string) => '{\\rtf1\\ansi\\deff0\n' + s.replace(/[\\{}]/g, m => '\\' + m).replace(/[^\x00-\x7F]/g, c => '\\u' + c.charCodeAt(0) + '?').replace(/\n/g, '\\par\n') + '}';
type Fn = (F: In[], o: Record<string, string>, eng?: any) => Promise<Out[]>;
export const pageHtml = (body: string) => `<!doctype html><html><head><meta charset="utf-8"><style>@page{margin:16mm}body{font-family:Helvetica,Arial,sans-serif;font-size:11pt;line-height:1.4;color:#111}h1,h2,h3{margin:12px 0 6px}p{margin:6px 0}table{border-collapse:collapse;margin:8px 0}td,th{border:1px solid #999;padding:4px 6px;font-size:9.5pt;vertical-align:top}img{max-width:100%}.slide,.chap{page-break-after:always}</style></head><body>${body}</body></html>`;
const office = (op: string): Fn => async ([f], _o, h) => [{ name: nm(f.n) + '.pdf', doc: await PDFDocument.load(await h.print(pageHtml((await h.call(op, { b64: toB64(f.b) })).data))) }];
export function rowsFromItems(items: { s: string; x: number; y: number; w: number }[]) {
  const its = items.filter(i => i.s.trim()).sort((a, b) => b.y - a.y || a.x - b.x), rows: (typeof its)[] = [];
  for (const it of its) { const r = rows[rows.length - 1]; if (r && Math.abs(r[0].y - it.y) < 3) r.push(it); else rows.push([it]); }
  return rows.map(r => { r.sort((a, b) => a.x - b.x); const cells: string[] = []; let end = -1e9;
    for (const it of r) { if (cells.length && it.x - end < 8) cells[cells.length - 1] += (it.x - end > 1.5 ? ' ' : '') + it.s; else cells.push(it.s); end = it.x + it.w; }
    return cells; });
}

export const T2: Record<string, Fn> = {
  assemble: async (F, o) => { const out = await PDFDocument.create(); for (const f of F) { const s = await ld(f.b); const ix = (o.r || '').trim() ? rngs(o.r, s.getPageCount()) : s.getPageIndices(); (await out.copyPages(s, ix)).forEach(p => out.addPage(p)); } return [{ name: 'assembled.pdf', doc: out }]; },
  nup: async ([f], o) => {
    const [c, r, land] = ({ 2: [2, 1, 1], 4: [2, 2, 0], 6: [3, 2, 1], 9: [3, 3, 0] } as any)[+o.n] ?? [2, 2, 0];
    const s = await ld(f.b), out = await PDFDocument.create(), [A, B] = SIZES.A4, [W, H] = land ? [B, A] : [A, B], emb = await out.embedPdf(s, s.getPageIndices()), per = c * r;
    for (let i = 0; i < emb.length; i += per) { const pg = out.addPage([W, H]); emb.slice(i, i + per).forEach((e, k) => { const cw = W / c, ch = H / r, z = Math.min((cw - 16) / e.width, (ch - 16) / e.height); pg.drawPage(e, { x: (k % c) * cw + (cw - e.width * z) / 2, y: H - (Math.floor(k / c) + 1) * ch + (ch - e.height * z) / 2, xScale: z, yScale: z }); }); }
    return [{ name: `${nm(f.n)}-${per}up.pdf`, doc: out }];
  },
  booklet: async ([f]) => {
    const s = await ld(f.b), n = s.getPageCount(), N = Math.ceil(n / 4) * 4, out = await PDFDocument.create(), e = await out.embedPdf(s, s.getPageIndices()), w0 = e[0].width, h0 = e[0].height;
    const put = (pg: any, em: any, side: number) => { if (!em) return; const z = Math.min(w0 / em.width, h0 / em.height); pg.drawPage(em, { x: side * w0 + (w0 - em.width * z) / 2, y: (h0 - em.height * z) / 2, xScale: z, yScale: z }); };
    const g = (i: number) => (i < n ? e[i] : null);
    for (let k = 0; k < N / 4; k++) { const a = out.addPage([w0 * 2, h0]); put(a, g(N - 1 - 2 * k), 0); put(a, g(2 * k), 1); const b = out.addPage([w0 * 2, h0]); put(b, g(2 * k + 1), 0); put(b, g(N - 2 - 2 * k), 1); }
    return [{ name: nm(f.n) + '-booklet.pdf', doc: out }];
  },
  halve: async ([f], o) => {
    const s = await ld(f.b), out = await PDFDocument.create();
    for (const i of s.getPageIndices()) { const [a, b] = await out.copyPages(s, [i, i]), w = a.getWidth(), h = a.getHeight();
      if (o.d === 'Top / bottom') { a.setCropBox(0, h / 2, w, h / 2); b.setCropBox(0, 0, w, h / 2); } else { a.setCropBox(0, 0, w / 2, h); b.setCropBox(w / 2, 0, w / 2, h); }
      out.addPage(a); out.addPage(b); }
    return [{ name: nm(f.n) + '-halved.pdf', doc: out }];
  },
  pagesize: async ([f], o) => {
    const s = await ld(f.b), out = await PDFDocument.create(), [W, H] = SIZES[o.s] ?? SIZES.A4, emb = await out.embedPdf(s, s.getPageIndices());
    emb.forEach(e => { const z = Math.min(W / e.width, H / e.height); out.addPage([W, H]).drawPage(e, { x: (W - e.width * z) / 2, y: (H - e.height * z) / 2, xScale: z, yScale: z }); });
    return [{ name: `${nm(f.n)}-${o.s || 'A4'}.pdf`, doc: out }];
  },
  overlay: async F => { if (F.length < 2) throw Error('Tick two PDFs: the first is the base, the second is drawn on top.'); const base = await ld(F[0].b); const [ov] = await base.embedPdf(F[1].b, [0]); base.getPages().forEach(p => p.drawPage(ov, { x: 0, y: 0, width: p.getWidth(), height: p.getHeight() })); return [{ name: nm(F[0].n) + '-overlay.pdf', doc: base }]; },
  nometa: async ([f]) => { const d = await ld(f.b); d.setTitle(''); d.setAuthor(''); d.setSubject(''); d.setKeywords([]); d.setProducer(''); d.setCreator(''); return [{ name: nm(f.n) + '-clean.pdf', doc: d, keep: true }]; },
  repair: async ([f]) => [{ name: nm(f.n) + '-repaired.pdf', doc: await PDFDocument.load(f.b, { ignoreEncryption: true, throwOnInvalidObject: false, updateMetadata: false }) }],
  flatform: async ([f]) => { const d = await ld(f.b); d.getForm().flatten(); return [{ name: nm(f.n) + '-flat.pdf', doc: d }]; },
  collage: async (F, o) => {
    const [c, r] = (o.g || '2x2').split('x').map(Number), out = await PDFDocument.create(), [W, H] = SIZES.A4, pg = out.addPage([W, H]), cw = W / c, ch = H / r;
    for (let i = 0; i < Math.min(F.length, c * r); i++) { const b = F[i].b, im = b[0] === 0x89 ? await out.embedPng(b) : await out.embedJpg(b), z = Math.min((cw - 16) / im.width, (ch - 16) / im.height);
      pg.drawImage(im, { x: (i % c) * cw + (cw - im.width * z) / 2, y: H - (Math.floor(i / c) + 1) * ch + (ch - im.height * z) / 2, width: im.width * z, height: im.height * z }); }
    return [{ name: 'collage.pdf', doc: out }];
  },
  write: async (_F, o) => {
    const out = await PDFDocument.create(), ft = await out.embedFont(StandardFonts.Helvetica), [W, H] = SIZES.A4, m = 50, fs = 12, lh = 16, lines: string[] = [];
    for (const para of String(o.t || '').replace(/[^\x20-\x7E\xA0-\xFF\n]/g, '?').split('\n')) { let cur = ''; for (const w of para.split(' ')) { const t = cur ? cur + ' ' + w : w; if (ft.widthOfTextAtSize(t, fs) > W - 2 * m && cur) { lines.push(cur); cur = w; } else cur = t; } lines.push(cur); }
    let pg = out.addPage([W, H]), y = H - m; for (const l of lines) { if (y < m) { pg = out.addPage([W, H]); y = H - m; } pg.drawText(l, { x: m, y, size: fs, font: ft }); y -= lh; }
    return [{ name: 'document.pdf', doc: out }];
  },
  toimg: async ([f], o, eng) => { const fmt = String(o.x || o.f || 'JPG').toUpperCase() === 'PNG' ? 'png' : 'jpg'; const r = await eng.call('render', { b64: toB64(f.b), scale: 2, fmt, q: 0.92, gray: false }); return [...r.parts].sort((a: any, b: any) => a.i - b.i).map((p: any) => ({ name: `${nm(f.n)}-p${p.i}.${fmt}`, b64: p.data })); },
  totext: async ([f], o, eng) => {
    const pages: string[] = (await eng.call('text', { b64: toB64(f.b) })).data, k = o.x || 'txt', base = nm(f.n), body = pages.map((t, i) => ({ t: t.trim(), i: i + 1 }));
    if (!body.some(p => p.t)) throw Error('No selectable text found. This PDF may be a scan.');
    if (k === 'md') return [{ name: base + '.md', text: `# ${base}\n\n` + body.map(p => `## Page ${p.i}\n\n${p.t}`).join('\n\n') }];
    if (k === 'html') return [{ name: base + '.html', text: `<!doctype html><meta charset="utf-8"><title>${esc(base)}</title>` + body.map(p => `<h2>Page ${p.i}</h2><p>${esc(p.t).replace(/\n/g, '<br>')}</p>`).join('') }];
    if (k === 'rtf') return [{ name: base + '.rtf', text: rtf(body.map(p => `Page ${p.i}\n${p.t}`).join('\n\n')) }];
    return [{ name: base + '.txt', text: body.map(p => p.t).join('\n\n') }];
  },
  copytext: async ([f], _o, eng) => { const pages: string[] = (await eng.call('text', { b64: toB64(f.b) })).data, t = pages.map(p => p.trim()).join('\n\n'); if (!t) throw Error('No selectable text found. This PDF may be a scan.'); return [{ name: '', show: t }]; },
  search: async ([f], o, eng) => { if (!String(o.q || '').trim()) throw Error('Type a word to search for.'); const r: any[] = (await eng.call('search', { b64: toB64(f.b), q: o.q.trim() })).data; return [{ name: '', show: r.length ? r.map(x => `Page ${x.p}: ...${x.s}...`).join('\n\n') : 'No matches found.' }]; },
  raster: async ([f], o, eng) => { const [scale, q] = Q[o.x || o.q] ?? Q.Medium; const r = await eng.call('render', { b64: toB64(f.b), scale, fmt: 'jpg', q, gray: false }); return [{ name: nm(f.n) + (o.x ? '-flat.pdf' : '-compressed.pdf'), doc: await rebuild(r.parts, scale) }]; },
  gray: async ([f], _o, eng) => { const r = await eng.call('render', { b64: toB64(f.b), scale: 2, fmt: 'jpg', q: 0.85, gray: true }); return [{ name: nm(f.n) + '-gray.pdf', doc: await rebuild(r.parts, 2) }]; },
  docx2pdf: office('docx2html'), xlsx2pdf: office('xlsx2html'), rtf2pdf: office('rtf2html'), odt2pdf: office('odt2html'), epub2pdf: office('epub2html'), pptx2pdf: office('pptx2html'),
  pdf2docx: async ([f], _o, h) => { const pages: string[] = (await h.call('text', { b64: toB64(f.b) })).data; if (!pages.some(p => p.trim())) throw Error('No selectable text found. This PDF may be a scan.'); return [{ name: nm(f.n) + '.docx', b64: (await h.call('mkdocx', { pages })).data }]; },
  pdf2xlsx: async ([f], _o, h) => { const pg: any[] = (await h.call('items', { b64: toB64(f.b) })).data, sheets = pg.map(rowsFromItems).filter(r => r.length); if (!sheets.length) throw Error('No selectable text found. This PDF may be a scan.'); return [{ name: nm(f.n) + '.xlsx', b64: (await h.call('mkxlsx', { sheets })).data }]; },
  protect: async ([f], o, h) => { if (!String(o.password || '').trim()) throw Error('Type a password first.'); return [{ name: nm(f.n) + '-protected.pdf', b64: (await h.call('qpdf', { b64: toB64(f.b), mode: 'protect', pw: o.password })).data, noOpen: true }]; },
  unlock: async ([f], o, h) => [{ name: nm(f.n) + '-unlocked.pdf', b64: (await h.call('qpdf', { b64: toB64(f.b), mode: 'unlock', pw: o.password || '' })).data }],
  imgconv: async (F, o, eng) => { const fmt = o.x === 'png' ? 'png' : 'jpg'; const out: Out[] = []; for (const f of F) out.push({ name: `${nm(f.n)}.${fmt}`, b64: (await eng.call('img', { b64: toB64(f.b), mime: mimeOf(f.n), fmt })).data }); return out; },
};
const FONTS: Record<string, [any, any]> = { sans: [StandardFonts.Helvetica, StandardFonts.HelveticaBold], serif: [StandardFonts.TimesRoman, StandardFonts.TimesRomanBold], mono: [StandardFonts.Courier, StandardFonts.CourierBold] };
export async function applyObjs(d: PDFDocument, objs: any[]) {
  const fc: Record<string, any> = {}, col = (h: string) => rgb(parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255);
  const font = async (f: string, b: boolean) => { const k = f + (b ? 1 : 0); return (fc[k] ??= await d.embedFont((FONTS[f] ?? FONTS.sans)[b ? 1 : 0])); };
  for (const o of objs) {
    const pg = d.getPage(o.p), H = pg.getHeight();
    if (o.t === 'text') {
      const th = ((o.r || 0) * Math.PI) / 180, c = Math.cos(th), s = Math.sin(th), px = o.pad ?? 1, py = px + o.s * 0.92, X = o.x + px * c - py * s, Y = o.y + px * s + py * c;
      pg.drawText(String(o.txt).replace(/[^\x20-\x7E\xA0-\xFF\n]/g, '?'), { x: X, y: H - Y, size: o.s, font: await font(o.f, o.b), color: col(o.c), lineHeight: o.s * 1.15, maxWidth: Math.max(20, o.w - 2 * px), rotate: degrees(-(o.r || 0)) });
    }
    else if (o.t === 'pen' || o.t === 'hl') for (let i = 1; i < o.pts.length; i++) pg.drawLine({ start: { x: o.pts[i - 1][0], y: H - o.pts[i - 1][1] }, end: { x: o.pts[i][0], y: H - o.pts[i][1] }, thickness: o.w, color: col(o.c), opacity: o.t === 'hl' ? 0.35 : 1, lineCap: LineCapStyle.Round });
    else if (o.t === 'rect') pg.drawRectangle({ x: Math.min(o.x1, o.x2), y: H - Math.max(o.y1, o.y2), width: Math.abs(o.x2 - o.x1), height: Math.abs(o.y2 - o.y1), borderColor: col(o.c), borderWidth: o.w });
    else if (o.t === 'white') pg.drawRectangle({ x: Math.min(o.x1, o.x2), y: H - Math.max(o.y1, o.y2), width: Math.abs(o.x2 - o.x1), height: Math.abs(o.y2 - o.y1), color: rgb(1, 1, 1), borderWidth: 0 });
    else if (o.t === 'ell') pg.drawEllipse({ x: (o.x1 + o.x2) / 2, y: H - (o.y1 + o.y2) / 2, xScale: Math.abs(o.x2 - o.x1) / 2, yScale: Math.abs(o.y2 - o.y1) / 2, borderColor: col(o.c), borderWidth: o.w });
    else if (o.t === 'line') pg.drawLine({ start: { x: o.x1, y: H - o.y1 }, end: { x: o.x2, y: H - o.y2 }, thickness: o.w, color: col(o.c), lineCap: LineCapStyle.Round });
    else if (o.t === 'sig') pg.drawImage(await d.embedPng(o.img), { x: o.x, y: H - o.y - o.h, width: o.w, height: o.h });
  }
}
