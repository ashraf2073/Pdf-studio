// Supabase Edge Function "convert": a safe middleman between the app and CloudConvert.
// Secrets (Edge Functions -> Secrets): CLOUDCONVERT_API_KEY and APP_KEY
import { encodeBase64 } from "https://deno.land/std@0.224.0/encoding/base64.ts";
const CC = "https://api.cloudconvert.com/v2";
const j = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });
Deno.serve(async (req) => {
  try {
    if (!Deno.env.get("APP_KEY") || req.headers.get("x-app-key") !== Deno.env.get("APP_KEY")) return j({ error: "Wrong app key" }, 401);
    const p = await req.json();
    const ext = String(p.name || "").split(".").pop()!.toLowerCase();
    let step: Record<string, unknown>;
    if (p.op === "convert") step = { operation: "convert", input_format: ext, output_format: p.to };
    else if (p.op === "ocr") step = { operation: "pdf/ocr", language: ["eng"] };
    else if (p.op === "pdfa") step = { operation: "pdf/a", conformance_level: "2b" };
    else if (p.op === "protect") step = { operation: "pdf/encrypt", set_password: p.password, set_owner_password: p.password + "-owner" };
    else if (p.op === "unlock") step = { operation: "pdf/decrypt", password: p.password };
    else return j({ error: "Unknown tool" }, 400);
    const auth = { "Content-Type": "application/json", Authorization: `Bearer ${Deno.env.get("CLOUDCONVERT_API_KEY")}` };
    const made = await (await fetch(`${CC}/jobs`, { method: "POST", headers: auth, body: JSON.stringify({ tasks: {
      imp: { operation: "import/base64", file: p.b64, filename: p.name },
      work: { ...step, input: "imp" },
      out: { operation: "export/url", input: "work" } } }) })).json();
    if (!made.data) throw new Error(made.message || "CloudConvert refused the job");
    let d = made.data;
    for (let i = 0; i < 60 && d.status !== "finished" && d.status !== "error"; i++) {
      await new Promise((r) => setTimeout(r, 2000));
      d = (await (await fetch(`${CC}/jobs/${d.id}`, { headers: auth })).json()).data;
    }
    if (d.status !== "finished") throw new Error(d.tasks?.find((t: any) => t.status === "error")?.message || "The conversion did not finish in time");
    const f = d.tasks.find((t: any) => t.name === "out").result.files[0];
    const bin = new Uint8Array(await (await fetch(f.url)).arrayBuffer());
    return j({ name: f.filename, b64: encodeBase64(bin) });
  } catch (e) { return j({ error: String((e as Error).message || e) }, 500); }
});
