import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
const H = (title: string, bg: string) => ({ title, headerStyle: { backgroundColor: bg }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' as const } });
export default function L() {
  return (<><StatusBar style="light" /><Stack screenOptions={{ contentStyle: { backgroundColor: '#F4F6FB' } }}>
    <Stack.Screen name="index" options={H('PDF Studio', '#E5322D')} />
    <Stack.Screen name="pdf-tools" options={H('PDF Tools', '#E5322D')} />
    <Stack.Screen name="cv" options={H('CV Builder', '#1FA463')} />
    <Stack.Screen name="qr" options={H('QR Designer', '#7B4BD8')} />
  </Stack></>);
}
