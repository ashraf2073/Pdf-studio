import React, { useMemo, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import Svg, { Defs, LinearGradient, Stop, Rect, Path, Image as SvgImage } from 'react-native-svg';
import * as IP from 'expo-image-picker';
import { Consent, State } from '../Consent';
import { payload, Kind, save, share } from '../lib';
import { build, svgStr, mkStyle, PRESETS, Style, SW, BG } from '../qrDesign';
import { download } from '../download';
import { Btn, C, Card, Chip } from '../ui';
const CONSENT = [
  { id: 'pub', required: true, label: 'I understand anyone who scans this QR code can read everything encoded in it (e.g. Wi-Fi password, contact card).' },
  { id: 'files', label: 'I allow the app to read the logo image I choose, on this device only.' }];
const F: Record<Kind, [string, string][]> = {
  url: [['v', 'Web link']], text: [['v', 'Text / note']], pdf: [['v', 'Public link to your PDF']], phone: [['phone', 'Phone number']],
  sms: [['phone', 'Phone number'], ['msg', 'Message']], wifi: [['ssid', 'Network name'], ['pass', 'Password (blank = open)']],
  vcard: [['first', 'First name'], ['last', 'Last name'], ['org', 'Organisation'], ['phone', 'Phone'], ['email', 'Email'], ['url', 'Website']] };
const Sw = ({ list, v, on }: { list: string[]; v: string; on: (c: string) => void }) => (
  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginVertical: 8 }}>{list.map(c => { const sel = v.toLowerCase() === c.toLowerCase(); return (
    <Pressable key={c} onPress={() => on(c)} style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: c, borderWidth: sel ? 4 : 1, borderColor: sel ? C.ink : '#D5DAE6' }} />); })}</View>);
const L = (t: string) => <Text style={{ fontWeight: '800', color: C.ink, marginTop: 10 }}>{t}</Text>;
const Preview = React.forwardRef<Svg, { g: any; s: Style; size: number }>(({ g, s, size }, ref) => {
  const u = g.u, ls = u * s.logoScale, lx = (u - ls) / 2, ec = s.eyeColor || s.c1;
  return (<Svg ref={ref} width={size} height={size} viewBox={`0 0 ${u} ${u}`}>
    <Defs><LinearGradient id="g" x1="0" y1="0" x2="1" y2="1"><Stop offset="0" stopColor={s.c1} /><Stop offset="1" stopColor={s.c2} /></LinearGradient></Defs>
    <Rect width={u} height={u} fill={s.bg} /><Path d={g.body} fill={s.grad ? 'url(#g)' : s.c1} />
    <Path d={g.ring} fill={ec} fillRule="evenodd" /><Path d={g.ball} fill={ec} />
    {s.logo ? (<><Rect x={lx - 0.8} y={lx - 0.8} width={ls + 1.6} height={ls + 1.6} rx={1.5} fill={s.bg} /><SvgImage href={{ uri: s.logo }} x={lx} y={lx} width={ls} height={ls} /></>) : null}
  </Svg>);
});
export default function Qr() {
  const [c, setC] = useState<State>({ ok: false, granted: {} }); const [k, setK] = useState<Kind>('url');
  const [f, setF] = useState<Record<string, string>>({}); const [st, setSt] = useState<Style>(mkStyle(PRESETS[1][1]));
  const ref = useRef<Svg>(null); const up = (p: Partial<Style>) => setSt(s => ({ ...s, ...p }));
  const { g, err } = useMemo(() => { try { return { g: build(payload(k, f), st), err: '' }; } catch (x: any) { return { g: null, err: x.message as string }; } }, [k, f, st]);
  const logo = async () => {
    const r = await IP.launchImageLibraryAsync({ mediaTypes: ['images'], base64: true, quality: 0.6 }); if (r.canceled) return;
    up({ logo: `data:${r.assets[0].mimeType ?? 'image/jpeg'};base64,${r.assets[0].base64}` });
  };
  const png = (dl: boolean) => ref.current?.toDataURL(async (b64: string) => {
    const name = `qr-${Date.now()}.png`, u = save(name, b64, true); dl ? await download(u, name, 'image/png') : await share(u, 'image/png');
  }, { width: 1024, height: 1024 } as any);
  const svg = async () => { const name = `qr-${Date.now()}.svg`; await download(save(name, svgStr(g!, st)), name, 'image/svg+xml'); };
  const pick = (a: string[], key: 'body' | 'eye' | 'ball') => a.map(x => <Chip key={x} t={x[0].toUpperCase() + x.slice(1)} on={st[key] === x} color={C.purple} onPress={() => up({ [key]: x } as any)} />);
  return (<ScrollView contentContainerStyle={{ padding: 16 }}>
    <Consent scope="qr" items={CONSENT} onChange={setC} />
    <Card>{L('What is it for?')}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>{(Object.keys(F) as Kind[]).map(x => <Chip key={x} t={x.toUpperCase()} on={k === x} color={C.purple} onPress={() => { setK(x); setF({}); }} />)}</View>
      {F[k].map(([key, ph]) => (<TextInput key={key} placeholder={ph} value={f[key] ?? ''} editable={c.ok} secureTextEntry={key === 'pass'} onChangeText={v => setF(p => ({ ...p, [key]: v }))}
        style={{ borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 12, marginTop: 10, backgroundColor: '#fff' }} />))}</Card>
    <Card style={{ alignItems: 'center' }}>{g ? <Preview ref={ref} g={g} s={st} size={260} /> : <Text style={{ color: C.mute, padding: 40 }}>{err}</Text>}</Card>
    <Card>{L('Personality')}<View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>{PRESETS.map(([n, p]) => <Chip key={n} t={n} color={C.pink} onPress={() => setSt(s => mkStyle({ ...p, logo: s.logo, logoScale: s.logoScale }))} />)}</View>
      {L('Dots')}<View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>{pick(['square', 'rounded', 'dots', 'diamond', 'bars'], 'body')}</View>
      {L('Corner frames')}<View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>{pick(['square', 'rounded', 'circle', 'leaf'], 'eye')}</View>
      {L('Corner centres')}<View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>{pick(['square', 'rounded', 'circle', 'leaf'], 'ball')}</View></Card>
    <Card>{L('Colours')}
      <View style={{ flexDirection: 'row', marginTop: 8 }}><Chip t="One colour" on={!st.grad} color={C.blue} onPress={() => up({ grad: false })} /><Chip t="Gradient" on={st.grad} color={C.blue} onPress={() => up({ grad: true })} /></View>
      {L(st.grad ? 'Colour 1' : 'Colour')}<Sw list={SW} v={st.c1} on={c1 => up({ c1 })} />
      {st.grad ? <>{L('Colour 2')}<Sw list={SW} v={st.c2} on={c2 => up({ c2 })} /></> : null}
      {L('Corner colour')}<View style={{ flexDirection: 'row', marginTop: 8 }}><Chip t="Same as dots" on={!st.eyeColor} color={C.blue} onPress={() => up({ eyeColor: '' })} /></View><Sw list={SW} v={st.eyeColor} on={eyeColor => up({ eyeColor })} />
      {L('Background')}<Sw list={BG} v={st.bg} on={bg => up({ bg })} />
      <Text style={{ color: C.mute, fontSize: 12 }}>Tip: dark dots on a light background scan best.</Text></Card>
    <Card>{L('Logo in the middle')}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>
        <Chip t={st.logo ? 'Change logo' : 'Add logo'} color={C.green} onPress={() => (c.granted.files ? logo() : Alert.alert('Permission needed', 'Tick the logo consent box at the top first.'))} />
        {st.logo ? <Chip t="Remove" color={C.red} onPress={() => up({ logo: undefined })} /> : null}</View>
      {st.logo ? <View style={{ flexDirection: 'row', marginTop: 4 }}>{([['Small', 0.16], ['Medium', 0.2], ['Large', 0.24]] as [string, number][]).map(([n, v]) => <Chip key={n} t={n} on={st.logoScale === v} onPress={() => up({ logoScale: v })} />)}</View> : null}</Card>
    <Btn t="Download PNG" icon="download" color={C.green} off={!c.ok || !g} onPress={() => png(true)} />
    <Btn t="Download SVG" icon="vector-square" color={C.blue} off={!c.ok || !g} onPress={svg} />
    <Btn t="Share" icon="share-variant" color={C.mute} off={!c.ok || !g} onPress={() => png(false)} />
  </ScrollView>);
}
