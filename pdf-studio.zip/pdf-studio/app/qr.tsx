import React, { useMemo, useRef, useState } from 'react';
import { ScrollView, Text, TextInput, Pressable, View } from 'react-native';
import Svg, { Rect, Path } from 'react-native-svg';
import { Consent, Btn, State } from '../src/Consent';
import * as L from '../src/lib';
const CONSENT = [{ id: 'pub', required: true, label: 'I understand anyone who scans this QR code can read everything encoded in it (e.g. Wi-Fi password, contact card).' }];
const F: Record<L.Kind, [string, string][]> = {
  url: [['v', 'Web link']], text: [['v', 'Text / note']], pdf: [['v', 'Public link to your PDF']], phone: [['phone', 'Phone number']],
  sms: [['phone', 'Phone number'], ['msg', 'Message']], wifi: [['ssid', 'Network name'], ['pass', 'Password (blank = open)']],
  vcard: [['first', 'First name'], ['last', 'Last name'], ['org', 'Organisation'], ['phone', 'Phone'], ['email', 'Email'], ['url', 'Website']] };
export default function Qr() {
  const [c, setC] = useState<State>({ ok: false, granted: {} }); const [k, setK] = useState<L.Kind>('url');
  const [f, setF] = useState<Record<string, string>>({}); const [fg, setFg] = useState('#000000'); const [bg, setBg] = useState('#FFFFFF');
  const ref = useRef<Svg>(null);
  const { m, err } = useMemo(() => { try { return { m: L.qr(L.payload(k, f)), err: '' }; } catch (x: any) { return { m: null, err: x.message as string }; } }, [k, f]);
  return (<ScrollView contentContainerStyle={{ padding: 16 }}>
    <Consent scope="qr" items={CONSENT} onChange={setC} />
    <ScrollView horizontal>{(Object.keys(F) as L.Kind[]).map(x => (<Pressable key={x} onPress={() => { setK(x); setF({}); }}
      style={{ padding: 10, marginRight: 8, borderRadius: 18, backgroundColor: k === x ? '#111' : '#eee' }}><Text style={{ color: k === x ? '#fff' : '#111' }}>{x.toUpperCase()}</Text></Pressable>))}</ScrollView>
    {F[k].map(([key, ph]) => (<TextInput key={key} placeholder={ph} value={f[key] ?? ''} editable={c.ok} secureTextEntry={key === 'pass'} onChangeText={v => setF(p => ({ ...p, [key]: v }))}
      style={{ borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 10, marginTop: 10 }} />))}
    <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
      <TextInput value={fg} onChangeText={setFg} style={{ flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 10 }} />
      <TextInput value={bg} onChangeText={setBg} style={{ flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 10 }} /></View>
    <View style={{ alignItems: 'center', marginVertical: 16 }}>{m ? (<Svg ref={ref} width={260} height={260} viewBox={`0 0 ${m.u} ${m.u}`}><Rect width={m.u} height={m.u} fill={bg} /><Path d={m.d} fill={fg} /></Svg>) : <Text style={{ color: '#777' }}>{err}</Text>}</View>
    <Btn t="Share PNG" off={!c.ok || !m} onPress={() => ref.current?.toDataURL(async b => L.share(L.save(`qr-${Date.now()}.png`, b, true), 'image/png'), { width: 1024, height: 1024 })} />
    <Btn t="Share SVG" off={!c.ok || !m} onPress={async () => m && L.share(L.save(`qr-${Date.now()}.svg`, L.qrSvg(m, fg, bg)), 'image/svg+xml')} />
  </ScrollView>);
}
