# PDF Studio – Made par Ashraf
1. npm install && npx expo install --fix
2. Dev: eas build -p android --profile development, then npx expo start --dev-client
3. APK: eas build -p android --profile preview   (or: npx expo prebuild && cd android && ./gradlew assembleRelease)
Everything runs on-device. No network calls.
