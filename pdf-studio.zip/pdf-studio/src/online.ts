import AsyncStorage from '@react-native-async-storage/async-storage';
import { toB64 } from './tools2';
export type Cfg = { url: string; key: string; anon?: string; mode?: 'supabase' | 'direct' };
const isSb = (u: string) => /supabase\.(co|in|net)/i.test(u);
const K = 'online:cfg2';
export const loadCfg = async (): Promise<Cfg | null> => { const v = await AsyncStorage.getItem(K); return v ? JSON.parse(v) : null; };
export const saveCfg = (c: Cfg) => AsyncStorage.setItem(K, JSON.stringify({ url: c.url.trim().replace(/\/+$/, ''), key: c.key.trim(), anon: (c.anon || '').trim(), mode: c.mode }));
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
async function wake(base: string, say: (m: string) => void) {
  for (let i = 0; i < 30; i++) {
    try { const j: any = await (await fetch(base + '/')).json(); if (j.ok) return; } catch {}
    if (i === 1) say('Waking up your converter… the first time can take a minute');
    await sleep(4000);
  }
  throw new Error('The converter did not wake up. Check its address in the settings and try again.');
}
export async function runOnline(cfg: Cfg, b: { op: string; name: string; bytes: Uint8Array; to?: string; password?: string }, say: (m: string) => void = () => {}) {
  const base = cfg.url.trim().replace(/\/+$/, ''), H = { 'Content-Type': 'application/json', 'x-app-key': cfg.key.trim() };
  if (cfg.mode ? cfg.mode === 'supabase' : isSb(base)) {
    say('Sending your file to your converter… this can take a minute or two');
    const SH: Record<string, string> = { 'Content-Type': 'application/json', 'x-app-key': cfg.key.trim() };
    if (cfg.anon?.trim()) { SH.Authorization = 'Bearer ' + cfg.anon.trim(); SH.apikey = cfg.anon.trim(); }
    const r = await fetch(base + '/functions/v1/convert', { method: 'POST', headers: SH, body: JSON.stringify({ op: b.op, name: b.name, to: b.to, password: b.password, b64: toB64(b.bytes) }) });
    const j: any = await r.json().catch(() => ({ error: `The converter sent an unexpected reply (HTTP ${r.status})` }));
    if (r.status === 401 && /jwt/i.test(String(j.message || j.error))) throw new Error('Supabase wants a key. Turn off "Verify JWT" for the convert function, or paste your anon key in the converter settings.');
    if (r.status === 401) throw new Error('The converter says the app key is wrong. Check it in the settings.');
    if (!r.ok || j.error) throw new Error(j.error || j.message || `Converter error ${r.status}`);
    return j as { name: string; b64: string };
  }
  await wake(base, say);
  say('Sending your file to the converter…');
  const s = await fetch(base + '/start', { method: 'POST', headers: H, body: JSON.stringify({ op: b.op, name: b.name, to: b.to, password: b.password, b64: toB64(b.bytes) }) });
  const sj: any = await s.json().catch(() => ({}));
  if (s.status === 401) throw new Error('The converter says the app key is wrong. Check it in the settings.');
  if (!s.ok || !sj.id) throw new Error(sj.detail || sj.error || `The converter refused the file (HTTP ${s.status})`);
  say('Converting… this can take a minute');
  for (let i = 0; i < 300; i++) {
    await sleep(2000);
    const r = await fetch(`${base}/job/${sj.id}`, { headers: H }), j: any = await r.json().catch(() => ({}));
    if (j.s === 'done') return j.r as { name: string; b64: string };
    if (j.s === 'error') throw new Error(j.e || 'The conversion failed');
    if (r.status === 404) throw new Error('The converter lost the job. Please try again.');
  }
  throw new Error('The conversion took too long. Try a smaller file.');
}
