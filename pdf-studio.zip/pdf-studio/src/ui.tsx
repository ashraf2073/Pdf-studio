import React from 'react';
import { Pressable, Text, View, ViewStyle } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
export const C = { red: '#E5322D', blue: '#1E6FE8', green: '#1FA463', orange: '#F28C00', purple: '#7B4BD8', teal: '#0FA3B1', pink: '#D6336C', ink: '#14181F', mute: '#6B7280', bg: '#F4F6FB', card: '#FFFFFF', line: '#E3E7F0' };
export const Icon = ({ n, c = '#fff', s = 24 }: { n: string; c?: string; s?: number }) => <MaterialCommunityIcons name={n as any} size={s} color={c} />;
export const Btn = ({ t, onPress, off, color = C.red, icon }: { t: string; onPress: () => void; off?: boolean; color?: string; icon?: string }) => (
  <Pressable disabled={off} onPress={onPress} style={{ backgroundColor: off ? '#C9CED8' : color, borderRadius: 14, paddingVertical: 14, paddingHorizontal: 16, marginTop: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
    {icon ? <Icon n={icon} /> : null}<Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>{t}</Text></Pressable>);
export const Tile = ({ icon, label, color, on, onPress }: { icon: string; label: string; color: string; on?: boolean; onPress: () => void }) => (
  <Pressable onPress={onPress} style={{ width: '30.5%', alignItems: 'center', marginBottom: 14 }}>
    <View style={{ width: 58, height: 58, borderRadius: 18, backgroundColor: color, alignItems: 'center', justifyContent: 'center', borderWidth: on ? 3 : 0, borderColor: C.ink }}><Icon n={icon} s={30} /></View>
    <Text style={{ marginTop: 6, fontSize: 12, fontWeight: on ? '800' : '600', textAlign: 'center', color: C.ink }}>{label}</Text></Pressable>);
export const Card = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => (
  <View style={[{ backgroundColor: C.card, borderRadius: 18, padding: 14, marginBottom: 14, borderWidth: 1, borderColor: C.line }, style]}>{children}</View>);
export const Chip = ({ t, on, color = C.blue, onPress }: { t: string; on?: boolean; color?: string; onPress: () => void }) => (
  <Pressable onPress={onPress} style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, backgroundColor: on ? color : '#E8ECF5', marginRight: 8, marginBottom: 8 }}>
    <Text style={{ color: on ? '#fff' : C.ink, fontWeight: '600' }}>{t}</Text></Pressable>);
