# PDF Studio – Made par Ashraf
1. npm install && npx expo install --fix
2. Dev: eas build -p android --profile development, then npx expo start --dev-client
3. APK: eas build -p android --profile preview   (or: npx expo prebuild && cd android && ./gradlew assembleRelease)
Everything runs on-device. No network calls.

## Notes
- First tap on any Download button asks for a folder once (pick or create Documents → PDF Studio). Android does not allow apps to use the Downloads root.
- "Add files" uses Android's picker once; after that files live inside the app.
