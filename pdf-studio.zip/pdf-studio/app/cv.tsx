import React, { useMemo, useState } from 'react';
import { ScrollView, Text, TextInput, View, Pressable, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import * as Print from 'expo-print';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Consent, Btn, State } from '../src/Consent';
import { share } from '../src/lib';
import { TPL, SEC, CVF, cvHtml } from '../src/cvTemplates';
const CONSENT = [
  { id: 'p', required: true, label: 'I consent to this app processing the details I type (name, contact, work history) on this device to build my CV.' },
  { id: 's', label: 'I consent to saving my draft locally on this device.' }];
const ACC = ['#1f6feb', '#12a57f', '#d1495b', '#7b4bd8', '#e08a00', '#111111'];
export default function Cv() {
  const [c, setC] = useState<State>({ ok: false, granted: {} });
  const [d, setD] = useState<any>({ tpl: 'minimal', accent: ACC[0], order: Object.keys(SEC), ...Object.fromEntries(CVF.map(([k, , v]: any) => [k, v])) });
  const html = useMemo(() => cvHtml(d), [d]);
  const set = (k: string, v: any) => setD((p: any) => ({ ...p, [k]: v }));
  const move = (i: number, x: number) => { const n = [...d.order], j = i + x; if (j < 0 || j >= n.length) return; [n[i], n[j]] = [n[j], n[i]]; set('order', n); };
  const exp = async () => {
    try { if (c.granted.s) await AsyncStorage.setItem('cv:draft', JSON.stringify(d));
      const { uri } = await Print.printToFileAsync({ html, width: 595, height: 842 }); await share(uri);
    } catch (x: any) { Alert.alert('Export failed', x.message); }
  };
  return (<ScrollView contentContainerStyle={{ padding: 16 }}>
    <Consent scope="cv" items={CONSENT} onChange={setC} />
    {CVF.map(([k, ph, , m]: any) => (<TextInput key={k} value={d[k]} onChangeText={v => set(k, v)} placeholder={ph} editable={c.ok} multiline={!!m}
      style={{ borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 10, marginTop: 8, minHeight: m ? 70 : undefined }} />))}
    <Text style={{ fontWeight: '700', marginTop: 14 }}>Template</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 6 }}>{Object.entries(TPL).map(([k, v]: any) => (
      <Pressable key={k} onPress={() => set('tpl', k)} style={{ padding: 10, marginRight: 8, borderRadius: 18, backgroundColor: d.tpl === k ? '#111' : '#eee' }}>
        <Text style={{ color: d.tpl === k ? '#fff' : '#111' }}>{v[0]}</Text></Pressable>))}</ScrollView>
    <Text style={{ fontWeight: '700', marginTop: 14 }}>Accent</Text>
    <View style={{ flexDirection: 'row', gap: 10, marginTop: 6 }}>{ACC.map(a => (<Pressable key={a} onPress={() => set('accent', a)}
      style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: a, borderWidth: d.accent === a ? 3 : 0, borderColor: '#888' }} />))}</View>
    <Text style={{ fontWeight: '700', marginTop: 14 }}>Section order</Text>
    {d.order.map((k: string, i: number) => (<View key={k} style={{ flexDirection: 'row', alignItems: 'center' }}><Text style={{ flex: 1 }}>{(SEC as any)[k]}</Text>
      <Pressable onPress={() => move(i, -1)}><Text style={{ padding: 8 }}>↑</Text></Pressable><Pressable onPress={() => move(i, 1)}><Text style={{ padding: 8 }}>↓</Text></Pressable></View>))}
    <View style={{ height: 480, borderWidth: 1, borderColor: '#ccc', marginTop: 12 }}>
      <WebView originWhitelist={['about:blank']} source={{ html }} javaScriptEnabled={false} scalesPageToFit /></View>
    <Btn t="Export CV as PDF" onPress={exp} off={!c.ok} />
  </ScrollView>);
}
