import { Pressable, ScrollView, Text, View } from 'react-native';
import { Link } from 'expo-router';
import { C, Icon } from '../src/ui';
const T: [string, string, string, string, string][] = [
  ['/pdf-tools', 'PDF Tools', '77 tools: edit, convert, organize', 'file-pdf-box', C.red],
  ['/pdf-tools?tool=edit', 'Edit PDF', 'Draw, highlight, add text', 'pencil', C.blue],
  ['/cv', 'CV Builder', '12 colourful templates', 'file-account', C.green],
  ['/qr', 'QR Designer', 'Styles, colours and a logo', 'qrcode', C.purple]];
export default function Home() {
  return (<ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
    <View style={{ backgroundColor: C.red, padding: 22, paddingBottom: 34, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 }}>
      <Text style={{ color: '#fff', fontSize: 28, fontWeight: '800' }}>PDF Studio</Text>
      <Text style={{ color: '#FFE3E1', marginTop: 4 }}>Edit, convert and design. Everything stays on your phone.</Text></View>
    <View style={{ padding: 16, flexDirection: 'row', flexWrap: 'wrap', gap: 14, marginTop: -18 }}>
      {T.map(([h, a, b, ic, col]) => (<Link key={h} href={h as any} asChild><Pressable style={{ width: '47%', backgroundColor: '#fff', borderRadius: 20, padding: 16, elevation: 3 }}>
        <View style={{ width: 54, height: 54, borderRadius: 16, backgroundColor: col, alignItems: 'center', justifyContent: 'center' }}><Icon n={ic} s={30} /></View>
        <Text style={{ fontWeight: '800', fontSize: 16, marginTop: 12, color: C.ink }}>{a}</Text><Text style={{ color: C.mute, marginTop: 2, fontSize: 12 }}>{b}</Text></Pressable></Link>))}</View>
    <Text style={{ textAlign: 'center', color: '#8A93A6', marginTop: 8 }}>Made par Ashraf</Text></ScrollView>);
}
