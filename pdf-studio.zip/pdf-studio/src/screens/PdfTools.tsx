import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View, Pressable, Alert } from 'react-native';
import * as DP from 'expo-document-picker';
import * as IP from 'expo-image-picker';
import { File } from 'expo-file-system';
import { Btn } from '../Consent';
import { TOOLS } from '../tools';
import { CREDIT, save, share } from '../lib';
const chip = (on: boolean) => ({ padding: 10, borderRadius: 18, backgroundColor: on ? '#111' : '#eee' });
export default function PdfTools() {
  const [i, setI] = useState(0); const [o, setO] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const t: any = TOOLS[i];
  const run = async () => {
    try {
      let src: { uri: string; name: string }[];
      if (t.img) { const r = await IP.launchImageLibraryAsync({ mediaTypes: ['images'], allowsMultipleSelection: true }); if (r.canceled) return; src = r.assets.map(a => ({ uri: a.uri, name: a.fileName ?? 'image.jpg' })); }
      else { const r = await DP.getDocumentAsync({ type: 'application/pdf', multiple: !!t.m, copyToCacheDirectory: true }); if (r.canceled) return; src = r.assets.map(a => ({ uri: a.uri, name: a.name })); }
      setBusy(true);
      const inp = await Promise.all(src.map(async s => ({ b: await new File(s.uri).bytes(), n: s.name })));
      const opts: Record<string, string> = {}; (t.o ?? []).forEach(([k, , d]: string[]) => (opts[k] = o[k] ?? d));
      const saved: string[] = [];
      for (const [d, n] of await t.run(inp, opts)) { d.setProducer(CREDIT); d.setCreator(CREDIT); saved.push(save(n, await d.save({ useObjectStreams: true }))); }
      if (saved.length > 1) Alert.alert('Done', `${saved.length} files saved in the app's outputs folder.`);
      await share(saved[0]);
    } catch (e: any) { Alert.alert('Could not finish', e.message); } finally { setBusy(false); }
  };
  return (<ScrollView contentContainerStyle={{ padding: 16 }}>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {TOOLS.map((x: any, k: number) => (<Pressable key={x.n} onPress={() => { setI(k); setO({}); }} style={chip(k === i)}><Text style={{ color: k === i ? '#fff' : '#111' }}>{x.n}</Text></Pressable>))}</View>
    <Text style={{ color: '#666', marginVertical: 10 }}>{t.d}</Text>
    {(t.o ?? []).map(([k, l, d, ch]: any) => (<View key={k + i} style={{ marginTop: 8 }}><Text>{l}</Text>
      {ch ? <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>{ch.map((c: string) => (<Pressable key={c} onPress={() => setO(p => ({ ...p, [k]: c }))} style={chip((o[k] ?? d) === c)}><Text style={{ color: (o[k] ?? d) === c ? '#fff' : '#111' }}>{c}</Text></Pressable>))}</View>
        : <TextInput value={o[k] ?? d} onChangeText={v => setO(p => ({ ...p, [k]: v }))} style={{ borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 10, marginTop: 4 }} />}</View>))}
    <Btn off={busy} t={busy ? 'Working…' : `Choose file and run: ${t.n}`} onPress={run} />
    <Text style={{ color: '#888', marginTop: 16 }}>Password protection and PDF → images need native modules; see README.</Text>
  </ScrollView>);
}
